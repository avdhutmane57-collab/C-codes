#include <stdio.h>
int main(){
    int n,i,j,count=0,flag;
    printf("Enter n: ");
    scanf("%d",&n);
    for(i=2;count<n;i++){
        flag=0;
        for(j=2;j<i;j++){
            if(i%j==0){
                flag=1;
                break;
            }
        }
        if(flag==0){
            printf("%d ",i);
            count++;
        }
    }
    return 0;
}
