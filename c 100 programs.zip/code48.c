#include <stdio.h>
int main(){
    float per;
    printf("Enter percentage: ");
    scanf("%f",&per);
    if(per>=75)
        printf("Distinction\n");
    else if(per>=60)
        printf("First Class\n");
    else if(per>=50)
        printf("Second Class\n");
    else
        printf("Fail\n");
    return 0;
}
