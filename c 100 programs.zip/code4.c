#include <stdio.h> 

int main() 
{ char N[50]; 
    printf("Enter your name: "); 
    scanf("%s", N); 
     printf("Hello, Robotic..!\n");  
     printf("Welcome %s\n", N);  
    
    return 0;
}