#include <stdio.h>
int main(){
    int n,i,a[50],pos=0,neg=0;
    printf("Enter n: ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        if(a[i]>=0)
            pos++;
        else
            neg++;
    }
    printf("Positive = %d\nNegative = %d\n",pos,neg);
    return 0;
}
