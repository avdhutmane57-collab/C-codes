#include <stdio.h>
int factorial(int n) {
    int f=1, i;
    for(i=1; i<=n; i++)
        f *= i;
    return f;
}
int main() {
    int i, sum, temp, digit;
    printf("Strong numbers up to 100: ");
    for(i=1; i<=100; i++) {
        temp=i;
        sum=0;
        while(temp!=0) {
            digit=temp%10;
            sum+=factorial(digit);
            temp/=10;
        }
        if(sum==i)
            printf("%d ", i);
    }
    return 0;
}
