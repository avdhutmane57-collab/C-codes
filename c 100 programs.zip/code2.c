#include <stdio.h>
int main(){
    printf("NAME-PARAS PRAVIN KASTURE");
    return 0;
}