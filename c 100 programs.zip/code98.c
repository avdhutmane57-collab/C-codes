#include <stdio.h>
#include <math.h>
int main() {
    double num, root;
    printf("Enter a number: ");
    scanf("%lf", &num);
    root = sqrt(num);
    printf("Square root = %.2lf\n", root);
    return 0;
}
