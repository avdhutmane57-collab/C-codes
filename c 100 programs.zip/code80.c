#include <stdio.h>
int main() {
    int start, end, i, sum=0;
    printf("Enter two numbers: ");
    scanf("%d %d", &start, &end);
    for(i=start; i<=end; i++)
        sum += i;
    printf("Sum = %d\n", sum);
    return 0;
}
