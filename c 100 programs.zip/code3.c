#include <stdio.h>
int main(){
    printf("Zeal College of Engineering & Research, Pune");
    return 0;
}