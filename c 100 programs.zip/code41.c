#include <stdio.h>
int main(){
    int s,area;
    printf("Enter side: ");
    scanf("%d",&s);
    area=s*s;
    printf("Area = %d\n",area);
    return 0;
}
