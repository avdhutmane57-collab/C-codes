#include <stdio.h>
int main(){
    int n,i,a[50],prod=1;
    printf("Enter n: ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        prod=prod*a[i];
    }
    printf("Product = %d\n",prod);
    return 0;
}
