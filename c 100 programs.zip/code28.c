#include <stdio.h>
int main(){
    int n,temp,d,sum=0;
    printf("Enter a number: ");
    scanf("%d",&n);
    temp=n;
    while(n>0){
        d=n%10;
        sum=sum+(d*d*d);
        n=n/10;
    }
    if(temp==sum)
        printf("Armstrong Number\n");
    else
        printf("Not Armstrong Number\n");
    return 0;
}
