#include <stdio.h>
int main(){
    int n,i,a[50],x,found=0;
    printf("Enter n: ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
    }
    printf("Enter element to search: ");
    scanf("%d",&x);
    for(i=0;i<n;i++){
        if(a[i]==x){
            printf("Found at position %d\n",i+1);
            found=1;
            break;
        }
    }
    if(found==0)
        printf("Not Found\n");
    return 0;
}
