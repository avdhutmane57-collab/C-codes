#include <stdio.h>
int main(){
    int a,b, rem;

    printf("Enter first number: ");
     scanf("%d",&a);

    printf("Enter second number: ");
    scanf("%d",&b);

    rem=a%b;
    
    printf("rem=%d\n",a%b);
    return 0;
}
