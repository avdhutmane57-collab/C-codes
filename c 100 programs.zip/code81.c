#include <stdio.h>
int main() {
    int start, end, i;
    long long product=1;
    printf("Enter two numbers: ");
    scanf("%d %d", &start, &end);
    for(i=start; i<=end; i++)
        product *= i;
    printf("Product = %lld\n", product);
    return 0;
}
