#include <stdio.h>
int main(){
    int a,b, multi;

    printf("Enter first number: ");
     scanf("%d",&a);

    printf("Enter second number: ");
    scanf("%d",&b);

    multi=a*b;
    printf("multi=%d\n",multi);
    return 0;
}
