#include <stdio.h>
int main(){
    int n,sq;

    printf("Enter a number: ");
    scanf("%d",&n);

    sq=n*n;
    
    printf("Square = %d\n",sq);
    return 0;
}
