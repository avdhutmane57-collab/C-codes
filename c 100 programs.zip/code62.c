#include <stdio.h>
int main(){
    int n,i,a[50],even=0,odd=0;
    printf("Enter n: ");
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d",&a[i]);
        if(a[i]%2==0)
            even++;
        else
            odd++;
    }
    printf("Even = %d\nOdd = %d\n",even,odd);
    return 0;
}
